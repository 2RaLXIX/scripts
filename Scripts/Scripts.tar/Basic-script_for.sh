#!/bin/bash

for i in {1..5};
	do echo $i
	sleep 1
done
#####################
#####################
echo
for FRUIT in apple banana cherry; do
	echo "I like $FRUIT."
	sleep 1
done
