#!/bin/bash

say_hello() {
	echo "Hello, $1!"
}

say_hello "Alice"
say_hello "Bob"
