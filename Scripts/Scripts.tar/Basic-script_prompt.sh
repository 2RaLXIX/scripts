#! /bin/bash

echo "Enter first number"
read a

echo "Enter second number"
read b

var=$((a+b))
echo "Sum is: "$var
