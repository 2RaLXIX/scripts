#! /bin/bash

greeting=Hello
name=Tux
echo $greeting $name
